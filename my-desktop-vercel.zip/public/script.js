const STORAGE_KEY = "my-desktop-apps-v1";
const BLANK_KEY = "my-desktop-auto-blank-v1";

const appGrid = document.getElementById("appGrid");
const addBtn = document.getElementById("addBtn");
const appDialog = document.getElementById("appDialog");
const settingsDialog = document.getElementById("settingsDialog");
const settingsBtn = document.getElementById("settingsBtn");

const appForm = document.getElementById("appForm");
const urlInput = document.getElementById("urlInput");
const nameInput = document.getElementById("nameInput");
const iconInput = document.getElementById("iconInput");
const preview = document.getElementById("preview");
const cancelBtn = document.getElementById("cancelBtn");
const blankToggle = document.getElementById("blankToggle");
const clock = document.getElementById("clock");

let selectedIcon = "";

function getApps() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
}

function saveApps(apps) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
}

function renderApps() {
  appGrid.innerHTML = "";

  for (const app of getApps()) {
    const button = document.createElement("button");
    button.className = "app";
    button.title = `${app.name}\n${app.url}`;

    const img = document.createElement("img");
    img.className = "icon";
    img.alt = "";
    img.src = app.icon || makeDefaultIcon(app.name);

    const name = document.createElement("span");
    name.className = "app-name";
    name.textContent = app.name;

    button.append(img, name);

    button.addEventListener("click", () => {
      // Apertura normal del navegador. No funciona como proxy.
      window.open(app.url, "_blank", "noopener,noreferrer");
    });

    appGrid.appendChild(button);
  }
}

function makeDefaultIcon(text) {
  const letter = (text || "A").trim().charAt(0).toUpperCase();
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="128" height="128">
      <rect width="128" height="128" rx="24" fill="#1677ff"/>
      <text x="64" y="78" text-anchor="middle"
            font-family="Arial" font-size="64" fill="white">${letter}</text>
    </svg>`;
  return "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg);
}

addBtn.addEventListener("click", () => {
  appForm.reset();
  selectedIcon = "";
  preview.innerHTML = "<span>Vista previa</span>";
  appDialog.showModal();
});

cancelBtn.addEventListener("click", () => appDialog.close());

iconInput.addEventListener("change", () => {
  const file = iconInput.files?.[0];
  if (!file) return;

  if (file.type !== "image/png") {
    alert("Selecciona un archivo PNG.");
    iconInput.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    selectedIcon = reader.result;
    preview.innerHTML = "";
    const img = document.createElement("img");
    img.src = selectedIcon;
    img.alt = "Vista previa";
    preview.appendChild(img);
  };
  reader.readAsDataURL(file);
});

appForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const url = urlInput.value.trim();
  const name = nameInput.value.trim();

  if (!/^https?:\/\//i.test(url)) {
    alert("La URL debe comenzar con http:// o https://");
    return;
  }

  const apps = getApps();
  apps.push({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    url,
    name,
    icon: selectedIcon
  });

  saveApps(apps);
  renderApps();
  appDialog.close();
});

settingsBtn.addEventListener("click", () => {
  blankToggle.checked = localStorage.getItem(BLANK_KEY) === "true";
  settingsDialog.showModal();
});

blankToggle.addEventListener("change", () => {
  localStorage.setItem(BLANK_KEY, String(blankToggle.checked));
});

function updateClock() {
  const now = new Date();
  clock.textContent = now.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}

renderApps();
updateClock();
setInterval(updateClock, 1000);
